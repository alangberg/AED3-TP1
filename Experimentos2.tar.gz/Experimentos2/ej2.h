#include <vector>
#include <iostream>
#include <algorithm>
#include <math.h>  
#include <string>

using namespace std;


vector<int > toBase3(long long int n);

vector<int > reverse(vector<int > v);

vector<int > balancear(vector<int > v);

void imprimirVector(vector<int > v);
